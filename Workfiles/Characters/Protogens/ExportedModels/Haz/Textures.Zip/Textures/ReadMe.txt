Some textures may be missing, this is due to the fact that you can directly set the value on these to either 1 or 0 and there isnt a need for a texture
It's a cheap optimization thing!